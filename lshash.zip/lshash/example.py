#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 28 23:23:37 2017

@author: linglimei
"""
import xlrd
from lshash import LSHash
fname = '/Users/linglimei/Documents/EC504/zipcode/zipcode.xls'

bk = xlrd.open_workbook(fname)
shxrange = range(bk.nsheets)

sh = bk.sheet_by_name("zipcode")
helpdic={}
#获取行数
nrows = sh.nrows
#获取列数
ncols = sh.ncols
city = []
longtitude = []
latitude = []
index = []
#获取第一行第一列数据 
for i in range(1,nrows):
    cell_value = sh.cell_value(i,0)
    city.append(cell_value)

for i in range(1,nrows):
    cell_value = sh.cell_value(i,3)
    latitude.append(cell_value)
    
    
for i in range(1,nrows):
    cell_value = sh.cell_value(i,4)
    longtitude.append(cell_value)
  
for i in range(1,nrows-1):
    helpdic[(latitude[i],longtitude[i])]=city[i]

lsh = LSHash(6,2)  

for i in range(1,nrows):
    #print(latitude[i],longtitude[i])
    try:
        lsh.index([latitude[i],longtitude[i]])
    except:
        pass
#print(LSHash._init_hashtables)
#print(helpdic[])
WTF=lsh.query([40.922326, -72.637078])[1][0]
wtf=helpdic[WTF]
print("Query result:",lsh.query([40.922326, -72.637078])[1],"Zipcode:",wtf)
